import { courses } from '../data/courses'
import CourseCard from './CourseCard'

function CoursesGrid() {
  return (
    <section id="cursos" className="max-w-6xl mx-auto px-4 py-12">
      <h2 className="text-3xl font-bold mb-8 text-center">Nuestros cursos</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {courses.map(c => <CourseCard key={c.id} course={c} />)}
      </div>
    </section>
  )
}
export default CoursesGrid
