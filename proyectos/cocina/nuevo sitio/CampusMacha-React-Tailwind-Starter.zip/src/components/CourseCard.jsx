function CourseCard({ course }) {
  return (
    <div className="bg-white rounded-2xl shadow-md hover:shadow-xl p-4 flex flex-col transition-all">
      <img src={course.image} alt={course.name} className="w-full h-44 object-cover rounded-xl mb-3" loading="lazy" />
      <h3 className="text-xl font-semibold">{course.name}</h3>
      <p className="text-gray-600 flex-1 mb-2">{course.description}</p>
      <div className="flex justify-between items-center mt-auto">
        <span className="font-bold text-lg text-primary">€{course.price}</span>
        <button className="bg-primary text-white rounded-xl px-4 py-2 font-bold hover:bg-secondary transition-all">Comprar</button>
      </div>
    </div>
  )
}
export default CourseCard
