function CertSection() {
  return (
    <section id="certificados" className="bg-white py-12">
      <div className="max-w-6xl mx-auto px-4 text-center">
        <h2 className="text-3xl font-bold mb-6">Certificados digitales</h2>
        <p className="mb-6 text-gray-700 max-w-xl mx-auto">
          Al completar cada curso, obtenés un certificado digital descargable, con tu nombre y firma digital.
        </p>
        <img src="/src/assets/img/certificado-ejemplo.webp" alt="Ejemplo de certificado" className="mx-auto rounded-xl shadow-md max-w-xs" loading="lazy" />
      </div>
    </section>
  )
}
export default CertSection
