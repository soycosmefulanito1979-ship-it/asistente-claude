function Hero() {
  return (
    <section className="bg-[url('/src/assets/img/hero.webp')] bg-cover bg-center text-white flex items-center min-h-[350px] md:min-h-[480px] px-8">
      <div className="max-w-2xl mx-auto py-12 md:py-20 text-center bg-black/40 rounded-2xl">
        <h1 className="text-4xl md:text-5xl font-extrabold mb-4">Aprende a cocinar como un chef profesional</h1>
        <p className="mb-8 text-lg">Clases prácticas, recetas reales, comunidad apasionada. ¡Sumate hoy!</p>
        <a href="#cursos" className="bg-primary hover:bg-secondary transition-colors text-white font-bold px-8 py-4 rounded-2xl text-xl shadow-lg">
          Ver cursos
        </a>
      </div>
    </section>
  )
}
export default Hero
