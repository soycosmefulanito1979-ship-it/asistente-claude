import { students } from '../data/students'

function StudentWall() {
  return (
    <section id="alumnos" className="bg-gray-100 py-12">
      <div className="max-w-6xl mx-auto px-4 text-center">
        <h2 className="text-3xl font-bold mb-6">Muro de alumnos</h2>
        <p className="mb-8 text-gray-700 max-w-xl mx-auto">Estos son algunos platos reales hechos por alumnos. ¿El próximo sos vos?</p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {students.map((s, i) => (
            <div key={i} className="flex flex-col items-center bg-white rounded-xl shadow p-2">
              <img src={s.image} alt={s.dish || 'Plato de alumno'} className="w-24 h-24 object-cover rounded-full mb-2" loading="lazy" />
              {s.name && <span className="font-semibold">{s.name}</span>}
              {s.dish && <span className="text-xs text-gray-500">{s.dish}</span>}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
export default StudentWall
