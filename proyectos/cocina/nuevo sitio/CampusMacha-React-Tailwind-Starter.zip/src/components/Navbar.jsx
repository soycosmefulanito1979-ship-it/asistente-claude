function Navbar() {
  return (
    <nav className="bg-white shadow sticky top-0 z-50">
      <div className="max-w-6xl mx-auto flex justify-between items-center py-4 px-6">
        <div className="flex items-center gap-2">
          <img src="/src/assets/img/logo.png" alt="Campus Macha" className="h-8" />
          <span className="font-bold text-xl text-primary">Campus Macha</span>
        </div>
        <div className="hidden md:flex gap-6">
          <a href="#cursos" className="hover:text-primary font-semibold">Cursos</a>
          <a href="#certificados" className="hover:text-primary font-semibold">Certificados</a>
          <a href="#alumnos" className="hover:text-primary font-semibold">Muro</a>
          <a href="#contacto" className="hover:text-primary font-semibold">Contacto</a>
        </div>
      </div>
    </nav>
  )
}
export default Navbar
