function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-6 mt-12">
      <div className="max-w-6xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center">
        <div className="mb-2 md:mb-0">
          <span>© {new Date().getFullYear()} Campus Macha. Todos los derechos reservados.</span>
        </div>
        <div className="flex gap-4">
          <a href="mailto:campusmacha@gmail.com" className="hover:text-primary">Contacto</a>
          <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="hover:text-primary">Instagram</a>
        </div>
      </div>
    </footer>
  )
}
export default Footer
