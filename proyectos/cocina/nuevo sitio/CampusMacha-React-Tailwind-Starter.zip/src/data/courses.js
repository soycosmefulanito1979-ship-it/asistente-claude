export const courses = [
  {
    "id": 1,
    "name": "Curso 1",
    "description": "Descripción breve del curso. Reemplazar con la real.",
    "image": "/src/assets/img/curso1.jpg",
    "price": 39.99
  },
  {
    "id": 2,
    "name": "Curso 2",
    "description": "Descripción breve del curso. Reemplazar con la real.",
    "image": "/src/assets/img/curso2.jpg",
    "price": 39.99
  },
  {
    "id": 3,
    "name": "Curso 3",
    "description": "Descripción breve del curso. Reemplazar con la real.",
    "image": "/src/assets/img/curso3.jpg",
    "price": 39.99
  },
  {
    "id": 4,
    "name": "Curso 4",
    "description": "Descripción breve del curso. Reemplazar con la real.",
    "image": "/src/assets/img/curso4.jpg",
    "price": 39.99
  },
  {
    "id": 5,
    "name": "Curso 5",
    "description": "Descripción breve del curso. Reemplazar con la real.",
    "image": "/src/assets/img/curso5.jpg",
    "price": 39.99
  }
];
