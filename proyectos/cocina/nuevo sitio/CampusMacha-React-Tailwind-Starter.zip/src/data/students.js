export const students = [
  {
    "name": "",
    "image": "/src/assets/img/muro1.jpg",
    "dish": ""
  },
  {
    "name": "",
    "image": "/src/assets/img/muro2.jpg",
    "dish": ""
  },
  {
    "name": "",
    "image": "/src/assets/img/muro3.jpg",
    "dish": ""
  }
];
