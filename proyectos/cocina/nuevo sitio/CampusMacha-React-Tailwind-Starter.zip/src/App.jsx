import Navbar from './components/Navbar'
import Hero from './components/Hero'
import CoursesGrid from './components/CoursesGrid'
import CertSection from './components/CertSection'
import StudentWall from './components/StudentWall'
import Footer from './components/Footer'

function App() {
  return (
    <div className="bg-gray-50 min-h-screen font-sans">
      <Navbar />
      <Hero />
      <CoursesGrid />
      <CertSection />
      <StudentWall />
      <Footer />
    </div>
  )
}
export default App
