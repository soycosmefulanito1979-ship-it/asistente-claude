/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: "#5A7D2A",
        secondary: "#FF7A00",
      },
      borderRadius: {
        "2xl": "1.5rem",
      },
      fontFamily: {
        sans: ["Inter", "Roboto", "sans-serif"],
      }
    },
  },
  plugins: [],
}
