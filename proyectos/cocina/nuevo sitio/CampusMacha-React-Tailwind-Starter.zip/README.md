# Campus Macha — React + Vite + Tailwind (listo para arrancar)

## Cómo usar
1) Abrí una terminal en esta carpeta y corré:
```
npm install
npm run dev
```
2) Abrí el link que te da la terminal (por ejemplo http://localhost:5173/)

## Dónde poner tus imágenes
Poné todas las fotos (logo, hero, cursos, muro) en:
```
/src/assets/img/
```
- El logo debe llamarse **logo.png** (Navbar ya lo referencia).
- La imagen del hero se espera como **hero.webp** (podés cambiarlo en `Hero.jsx`).
- Para el muro, usá **muro1.jpg**, **muro2.jpg**, **muro3.jpg** (o editá `src/data/students.js`).

## Cargar los 35 cursos reales
Editá `src/data/courses.js` y reemplazá los 5 ejemplos por tus 35 cursos con esta forma:
```js
export const courses = [
  {
    id: 1,
    name: "Nombre del curso",
    description: "Descripción corta del curso",
    image: "/src/assets/img/nombre-de-la-imagen.jpg",
    price: 39.99
  },
  // ... hasta 35
];
```

## Archivos clave
- `index.html` → apunta a `/src/main.jsx`
- `src/main.jsx` → arranca la app
- `src/App.jsx` → arma la página con las secciones
- `src/components/*` → componentes
- `src/data/*` → datos (cursos y muro)
- `tailwind.config.js` + `postcss.config.js` → configuración Tailwind

¡Listo! Copiá tus imágenes y datos reales y a vender cursos ;)
